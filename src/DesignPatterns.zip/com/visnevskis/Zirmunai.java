package com.visnevskis;

public class Zirmunai extends District {

    @Override
    void getName() {
        this.name = "Zirmunai";
    }

    @Override
    void getResidents() {
        this.residents = 15996;
    }

    @Override
    void getAveragePrice() {
        this.averagePrice = 2;
    }
}

package com.visnevskis;

public class Verkiai extends District {

    @Override
    void getName() {
        name = "Verkiai";
    }

    @Override
    void getResidents() {
        residents = 30856;
    }

    @Override
    void getAveragePrice() {
        averagePrice = 2.5;
    }
}

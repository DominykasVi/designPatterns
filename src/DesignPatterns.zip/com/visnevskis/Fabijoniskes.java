package com.visnevskis;

public class Fabijoniskes extends District {


    @Override
    void getName() {
        name = "Fabijoniskes";
    }

    @Override
    void getResidents() {
        residents = 27892;
    }

    @Override
    void getAveragePrice() {
        averagePrice = 3.5;
    }
}

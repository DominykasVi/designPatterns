package com.visnevskis;

public interface DistrictContainer {
    public Iterator getIterator();
}

package com.visnevskis;

public class Antakalnis extends District {

    @Override
    void getName() {
        name = "Antakalnis";
    }

    @Override
    void getResidents() {
        residents = 39697;
    }

    @Override
    void getAveragePrice() {
        averagePrice = 1.5;
    }


}

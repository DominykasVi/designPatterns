package com.visnevskis;

public interface Iterator {
    public boolean hasNext();
    public District next();
}

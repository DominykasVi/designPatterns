package com.visnevskis;

public class Main {

    public static void main(String[] args) {
        //Uses Factory and Iterator design patterns
        //lambda functions are user in UserInterface class with button action listeners
        //layout looks best with 3 district route
        UserInterface userInterface = new UserInterface();

    }
}
